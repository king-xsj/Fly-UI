import FlyLoading from "./src/index"

export default FlyLoading;