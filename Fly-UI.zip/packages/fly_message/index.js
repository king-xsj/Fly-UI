import FlyMessage from "./src/index"

export default FlyMessage;